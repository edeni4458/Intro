function login(element) {
    console.log("element clicked", element);
    element.innerText="Logout";
}


function Remove(Removed) {
    console.log("Removed clicked", Removed);
    Removed.innerText="Removed";
}



