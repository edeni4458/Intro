function removeElement() {
    const element = document.getElementById("bTn");
    element.remove();
}




