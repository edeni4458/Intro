


function nextImage() {
    console.log("go to the next image");
    var giF = document.querySelector
        ("#jSp");
    jSp.src="./Images/spidertocat.png"
}

function prevImage() {
var giF = document.querySelector
    ("#jSp");
jSp.src="./Images/Terracottocat_Single.png"
}


