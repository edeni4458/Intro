function changeTo(){
    var swap = document.querySelector('#logOut')
    swap.innerText = 'Logout'
}

function hideIt(){
    var hidIt = document.querySelector('#removIt');
    hidIt.remove()
}

