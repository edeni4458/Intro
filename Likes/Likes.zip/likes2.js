console.log("Christ is King");




var count = 9;
var countElement = document.querySelector("#count");
console.log(countElement);


function add1(){
    count ++;
    countElement.innerText =  count + " like (s)";
    console.log(count);
}


var count2 = 12;
var count2Element = document.querySelector("#count2");
console.log(count2Element);

function add2(){
    count ++;
    count2Element.innerText = count + " like (s)";
    console.log(count2);
}



var count3 = 9;
var count3Element = document.querySelector("#count3");
console.log(count3Element);

function add3(){
    count ++;
    count3Element.innerText = count + " likes (s)";
    console.log(count3);
}